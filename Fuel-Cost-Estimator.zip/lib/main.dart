import 'package:flutter/material.dart';
import 'home.dart';

void main() {
  runApp(const FuelCostEstimatorApp());
}

class FuelCostEstimatorApp extends StatelessWidget {
  const FuelCostEstimatorApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fuel Cost Estimator',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Roboto',
      ),
      home: const HomePage(),
    );
  }
}
