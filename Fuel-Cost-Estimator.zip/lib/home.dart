import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController distanceController = TextEditingController();
  final TextEditingController fuelEfficiencyController =
      TextEditingController();
  final TextEditingController fuelPriceController = TextEditingController();

  double? totalCost;

  void calculateCost() {
    double distance = double.tryParse(distanceController.text) ?? 0;
    double fuelEfficiency = double.tryParse(fuelEfficiencyController.text) ?? 0;
    double fuelPrice = double.tryParse(fuelPriceController.text) ?? 0;

    if (distance > 0 && fuelEfficiency > 0 && fuelPrice > 0) {
      setState(() {
        totalCost = (distance / fuelEfficiency) * fuelPrice;
      });
    } else {
      setState(() {
        totalCost = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Please enter valid values in all fields!'),
        backgroundColor: Colors.redAccent,
      ));
    }
  }

  void resetFields() {
    setState(() {
      distanceController.clear();
      fuelEfficiencyController.clear();
      fuelPriceController.clear();
      totalCost = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fuel Cost Estimator'),
        backgroundColor: Colors.green,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Estimate your Fuel Cost',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 20),
            _buildInputField(
              controller: distanceController,
              label: 'Distance Traveled (km)',
              hintText: 'Enter distance in kilometers',
              icon: Icons.directions_car,
            ),
            const SizedBox(height: 20),
            _buildInputField(
              controller: fuelEfficiencyController,
              label: 'Fuel Efficiency (km/l)',
              hintText: 'Enter fuel efficiency in km/l',
              icon: Icons.local_gas_station,
            ),
            const SizedBox(height: 20),
            _buildInputField(
              controller: fuelPriceController,
              label: 'Fuel Price (per liter)',
              hintText: 'Enter price per liter in \$',
              icon: Icons.attach_money,
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: calculateCost,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 15),
                    backgroundColor: Colors.green,
                  ),
                  child: const Text(
                    'Calculate',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                ElevatedButton(
                  onPressed: resetFields,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 15),
                    backgroundColor: Colors.grey,
                  ),
                  child: const Text(
                    'Reset',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            if (totalCost != null)
              Center(
                child: Column(
                  children: [
                    const Text(
                      'Estimated Fuel Cost:',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '\$${totalCost!.toStringAsFixed(2)}',
                      style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: Colors.green),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hintText,
    required IconData icon,
  }) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        hintText: hintText,
        prefixIcon: Icon(icon, color: Colors.green),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
