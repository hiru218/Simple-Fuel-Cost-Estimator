package com.example.fuel_cost_estimator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
